import torch
import torch.nn as nn
import torch.nn.functional as F


def make_model(args, parent=False):
    return LGCNET(scale=args.scale[0])


class LGCNET(nn.Module):
    def __init__(self, scale: int, n_colors=3, nfeats=32, **kwargs):
        super(LGCNET, self).__init__()
        self.scale = scale

        self.conv1 = nn.Conv2d(n_colors, nfeats, kernel_size=3, stride=1, padding=1, bias=True)
        self.conv2 = nn.Conv2d(nfeats, nfeats, kernel_size=3, stride=1, padding=1, bias=True)
        self.conv3 = nn.Conv2d(nfeats, nfeats, kernel_size=3, stride=1, padding=1, bias=True)
        self.conv4 = nn.Conv2d(nfeats, nfeats, kernel_size=3, stride=1, padding=1, bias=True)
        self.conv5 = nn.Conv2d(nfeats, nfeats, kernel_size=3, stride=1, padding=1, bias=True)
        self.conv6 = nn.Conv2d(nfeats * 3, nfeats * 2, kernel_size=5, stride=1, padding=2, bias=True)
        self.conv7 = nn.Conv2d(nfeats * 2, 3, kernel_size=3, stride=1, padding=1, bias=True)
        self.relu = nn.ReLU()

    def forward(self, x):
        x = F.interpolate(x, (x.size(2) * self.scale, x.size(3) * self.scale), mode='bicubic', align_corners=False)
        residual = x
        im1 = self.relu(self.conv1(x))
        im2 = self.relu(self.conv2(im1))
        im3 = self.relu(self.conv3(im2))
        im4 = self.relu(self.conv4(im3))
        im5 = self.relu(self.conv5(im4))
        out = self.relu(self.conv6(torch.cat((im3, im4, im5), dim=1)))
        out = self.conv7(out) + residual
        return out