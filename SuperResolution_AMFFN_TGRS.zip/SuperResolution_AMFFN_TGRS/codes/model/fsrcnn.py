import torch.nn as nn


def make_model(args, parent=False):
    return FSRCNN(scale=args.scale[0])


class FSRCNN(nn.Module):
    def __init__(self, scale: int, **kwargs):
        super(FSRCNN, self).__init__()
        self.scale = scale

        # Feature extraction layer.
        self.feature_extraction = nn.Sequential(
            nn.Conv2d(3, 56, (5, 5), (1, 1), (2, 2)),
            nn.PReLU(56)
        )
        # Shrinking layer.
        self.shrink = nn.Sequential(
            nn.Conv2d(56, 12, (1, 1), (1, 1), (0, 0)),
            nn.PReLU(12)
        )
        # Mapping layer.
        self.map = nn.Sequential(
            nn.Conv2d(12, 12, (3, 3), (1, 1), (1, 1)),
            nn.PReLU(12),
            nn.Conv2d(12, 12, (3, 3), (1, 1), (1, 1)),
            nn.PReLU(12),
            nn.Conv2d(12, 12, (3, 3), (1, 1), (1, 1)),
            nn.PReLU(12),
            nn.Conv2d(12, 12, (3, 3), (1, 1), (1, 1)),
            nn.PReLU(12)
        )
        # Expanding layer.
        self.expand = nn.Sequential(
            nn.Conv2d(12, 56, (1, 1), (1, 1), (0, 0)),
            nn.PReLU(56)
        )
        # Deconvolution layer.
        self.deconv = nn.ConvTranspose2d(56, 3, (9, 9), (scale, scale), (4, 4), (scale - 1, scale - 1))

    def forward(self, x):
        out = self.feature_extraction(x)
        out = self.shrink(out)
        out = self.map(out)
        out = self.expand(out)
        out = self.deconv(out)
        return out