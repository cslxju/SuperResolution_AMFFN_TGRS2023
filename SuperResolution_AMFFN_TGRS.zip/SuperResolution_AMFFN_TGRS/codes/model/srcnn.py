import torch.nn as nn
import torch.nn.functional as F


def make_model(args, parent=False):
    return SRCNN(scale=args.scale[0])


class SRCNN(nn.Module):
    def __init__(self, scale: int, **kwargs):
        super(SRCNN, self).__init__()
        self.scale = scale

        # 特征提取层
        self.features = nn.Sequential(
            nn.Conv2d(3, 64, (9, 9), (1, 1), (4, 4)),
            nn.ReLU(True)
        )
        # 非线性映射层
        self.map = nn.Sequential(
            nn.Conv2d(64, 32, (1, 1), (1, 1), (0, 0)),
            nn.ReLU(True)
        )
        # 重建图层
        self.reconstruction = nn.Conv2d(32, 3, (5, 5), (1, 1), (2, 2))

    def forward(self, x):
        x = F.interpolate(x, (x.size(2) * self.scale, x.size(3) * self.scale), mode='bicubic', align_corners=False)
        out = self.features(x)
        out = self.map(out)
        out = self.reconstruction(out)
        return out