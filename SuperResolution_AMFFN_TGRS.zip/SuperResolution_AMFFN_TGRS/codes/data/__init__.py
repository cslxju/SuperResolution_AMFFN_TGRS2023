from torch.utils.data import DataLoader


def create_dataloaders(args):
    """create dataloader"""
    if args.dataset == 'AID':
        from data.aid import AIDataset
        training_set = AIDataset(args, root_dir='G:\datasets\yaogan\dataset\AID-dataset/train',
                                 train=True)
        val_set = AIDataset(args, root_dir='G:\datasets\yaogan\dataset\AID-dataset/val',
                            train=False)
        test_set = AIDataset(args, root_dir='G:\datasets\yaogan\dataset/AID-dataset/val',
                             train=False)
    elif args.dataset == 'UCMerced':
        from data.ucmerced import UCMercedDataset
        training_set = UCMercedDataset(args, root_dir='../../../datasets/UCMerced/train',
                                       train=True)
        val_set = UCMercedDataset(args, root_dir='../../../datasets/UCMerced/val',
                                  train=False)
        test_set = UCMercedDataset(args, root_dir='../../../datasets/UCMerced/test',
                                   train=False)
    elif args.dataset == 'RSSCN7':
        from data.rsscn7 import RSSCN7Dataset
        training_set = RSSCN7Dataset(args, root_dir='../../../datasets/RSSCN7/train',
                                     train=True)
        val_set = RSSCN7Dataset(args, root_dir='../../../datasets/RSSCN7/val',
                                train=False)
        test_set = RSSCN7Dataset(args, root_dir='../../../datasets/RSSCN7/test',
                                 train=False)
    elif args.dataset == 'DIV2K':
        from data.div2k import DIV2KDataset
        training_set = DIV2KDataset(args, root_dir='G:\datasets\yaogan\dataset\DIV2K/train',
                                    train=True)
        val_set = DIV2KDataset(args, root_dir='G:\datasets\yaogan\dataset\DIV2K/val',
                               train=False)
        test_set = DIV2KDataset(args, root_dir='G:\datasets\yaogan\dataset/test\Set14',
                                train=False)
    else:
        raise NotImplementedError(
            'Wrong dataset name %s ' % args.dataset)

    datatrain = []
    dataval = []
    datatest = []
    datatrain.append(training_set)
    dataval.append(val_set)
    datatest.append(test_set)
    dataloaders = {'train': DataLoader(datatrain[0], batch_size=args.batch_size,
                                       shuffle=True, num_workers=args.n_threads),
                   'val': DataLoader(dataval[0], batch_size=args.batch_size,
                                     shuffle=False, num_workers=args.n_threads),
                   'test': DataLoader(datatest[0], batch_size=1,
                                      shuffle=False, num_workers=1),
                   }

    return dataloaders
